## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(hydromad)
library(ggplot2)

load("data/hbv_vignette.Rdata")

# Create own gather function
gather <- function(df) {
  cols <- colnames(df)[-1]
  out <- data.frame()
  for(col in cols) {
    tmp <- df[,c("Date", col)]
    tmp$name <- col
    colnames(tmp) <- c("Date", "value", "name")
    out <- rbind(out, tmp)
  }
  return(out[,c(1,3,2)])
}

## ----data---------------------------------------------------------------------
data(Corin) 
head(Corin)

## ----mod, message=FALSE, warning=FALSE, eval=FALSE----------------------------
#  mod <- hydromad(DATA = Corin,
#                  sma = "hbv",
#                  routing = "hbvrouting")
#  # Calibrate the default parameter ranges
#  fit <- fitByOptim(mod, method = "PORT")

## ----modplot, fig.width=6, fig.height=4, fig.align="center"-------------------
summary(fit)
xyplot(fit)

## ---- eval=FALSE--------------------------------------------------------------
#  mod <- hydromad(DATA = Corin,
#                  sma = "hbv",
#                  routing = "hbvrouting",
#                  PET = list("PET" = corin_pet,
#                             "Tmean" = corin_tmean),
#                  cet = C(0.01, 1))

## -----------------------------------------------------------------------------
mod <- hydromad(DATA = Corin,
                sma = "hbv",
                routing = "hbvrouting",
                tt = 0, # Snow
                cfmax = 6.36,
                sfcf = 1, 
                cfr = 0.05,
                cwh = 0.19,
                fc = 317, # Soil
                lp = 0.89, 
                beta = 2.68,
                perc = 0.89, # Routing
                uzl = 71.34,
                k0 = 0.11,
                k1 = 0.15,
                k2 = 0.04, 
                maxbas = 1.5,
                return_state = TRUE,
                return_components = TRUE,
                initialise_sm = TRUE,
                initial_slz = Corin$Q[1] / 0.04, # first Q timestep / k2
                warmup = 0)

## ---- echo=FALSE--------------------------------------------------------------
hbvl <- hbvl_corin_results
hbvl <- hbvl[,c("Date", "AET", "PET", "Snow", "SM", "Recharge", "SUZ", "SLZ", "Q0", "Q1", "Q2", "Qsim")]
hbvl <- gather(hbvl)
hbvl$Model <- "HBV-light"
hbvl$name <- factor(hbvl$name, c("Snow", "SM", "PET", "AET", "Recharge", "SUZ", "SLZ", "Q0", "Q1", "Q2", "Qsim"))
hbvl <- hbvl[order(hbvl$Date),]
hbvl <- hbvl[order(hbvl$name),]

# Convert mod results to dataframe
mod_df <- cbind(index(mod$U), data.frame(mod$U), data.frame(mod$fitted.values))
colnames(mod_df) <- c("Date", "Recharge", "Snow", "SM", "PET", "AET", "Qsim", "SUZ", "SLZ", "Q0", "Q1", "Q2")
mod_df <- gather(mod_df)
mod_df$Model <- "hydromad"
mod_df$name <- factor(mod_df$name, c("Snow", "SM", "PET", "AET", "Recharge", "SUZ", "SLZ", "Q0", "Q1", "Q2", "Qsim"))
mod_df <- mod_df[order(mod_df$Date),]
mod_df <- mod_df[order(mod_df$name),]


df <- rbind(hbvl, mod_df)
df2 <- hbvl[,c("Date", "name", "value")]
colnames(df2) <- c("Date", "name", "HBV-light")
df2$hydromad <- mod_df$value
df2$diff <- df2$`HBV-light`-df2$hydromad

## ----comparison, fig.width=7, fig.height=6, fig.align="centre"----------------
ggplot(df, aes(Date, value, col=Model)) +
  geom_line(alpha=0.5) +
  ylab("Value (mm)") +
  facet_wrap(~name, scales="free_y", ncol = 3)

## ----differences, fig.width=7, fig.height=6, fig.align="centre"---------------
ggplot(df2, aes(Date, diff,1)) +
  geom_line() +
  ylab("Value (mm)") +
  facet_wrap(~name, ncol = 3)

## -----------------------------------------------------------------------------
mod <- hydromad(DATA = hbv_land,
                sma = "hbv",
                routing = "hbvrouting",
                tt = -1.76, # Snow
                cfmax = 2.98,
                sfcf = 0.73, 
                cfr = 0.05,
                cwh = 0.1,
                fc = 285, # Soil
                lp = 0.75, 
                beta = 3.43,
                cet = 0.1,
                perc = 1.02, # Routing
                uzl = 17.6,
                k0 = 0.25,
                k1 = 0.09,
                k2 = 0.06, 
                maxbas = 2.4,
                return_state = TRUE,
                return_components = TRUE,
                initialise_sm = TRUE,
                initial_slz = hbv_land$Q[1] / 0.06, # first Q timestep / k2
                warmup = 0,
                PET = list("PET"=hbv_land_pet, "Tmean" = hbv_land_tmean))

## ---- echo=FALSE--------------------------------------------------------------
# Read in HBV-light results
hbvl <- hbvl_hbvland_results
hbvl <- hbvl[,c("Date", "AET", "PET", "Snow", "SM", "Recharge", "SUZ", "SLZ", "Q0", "Q1", "Q2", "Qsim")]
hbvl <- gather(hbvl)
hbvl$Model <- "HBV-light"
hbvl$name <- factor(hbvl$name, c("Snow", "SM", "PET", "AET", "Recharge", "SUZ", "SLZ", "Q0", "Q1", "Q2", "Qsim"))
hbvl <- hbvl[order(hbvl$Date),]
hbvl <- hbvl[order(hbvl$name),]

# Convert mod results to dataframe
mod_df <- cbind(index(mod$U), data.frame(mod$U), data.frame(mod$fitted.values))
colnames(mod_df) <- c("Date", "Recharge", "Snow", "SM", "PET", "AET", "Qsim", "SUZ", "SLZ", "Q0", "Q1", "Q2")
mod_df <- gather(mod_df)
mod_df$Model <- "hydromad"
mod_df$name <- factor(mod_df$name, c("Snow", "SM", "PET", "AET", "Recharge", "SUZ", "SLZ", "Q0", "Q1", "Q2", "Qsim"))
mod_df <- mod_df[order(mod_df$Date),]
mod_df <- mod_df[order(mod_df$name),]


df <- rbind(hbvl, mod_df)
df2 <- hbvl[,c("Date", "name", "value")]
colnames(df2) <- c("Date", "name", "HBV-light")
df2$hydromad <- mod_df$value
df2$diff <- df2$`HBV-light`-df2$hydromad

## ----comparison2, fig.width=7, fig.height=6, fig.align="centre"---------------
ggplot(df, aes(Date, value, col=Model)) +
  geom_line(alpha=0.5) +
  ylab("Value (mm)") +
  facet_wrap(~name, scales="free_y", ncol = 3)

## ----differences2, fig.width=7, fig.height=6, fig.align="centre"--------------
ggplot(df2, aes(Date, diff,1)) +
  geom_line() +
  ylab("Value (mm)") +
  facet_wrap(~name, ncol = 3)

