library(testthat)
library(hydromad)

test_check("hydromad")
