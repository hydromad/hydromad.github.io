rand<-function(m,n) matrix(runif(m*n),m,n)
randn<-function(m,n) matrix(rnorm(m*n),m,n)